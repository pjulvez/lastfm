
		var myapplication_name="lastfmPol";
		var myAPI_key="c9a7686c3a1868336eab3931fd069b03";
		var myshared_secret="f461e3701b1e4fc9888163616d65f546";
		var token ="My2CItMIlBuHW8YbaSyT6BmnpNFsSbSm"
		var apiSig="d77ddf1654e32242fac94ca88ef81677";

function myLoginFunction(){
			/*
			params api_key ( my api key)
			cb the web that goes when user is authenticated relative path ( depends on the server is launched): http://localhost:3000/mainpage.ht*/
			var url= 'http://www.last.fm/api/auth/?api_key=c9a7686c3a1868336eab3931fd069b03&cb=http://localhost/lastfmpol/mainpage.html';

			window.location.replace(url);
}
